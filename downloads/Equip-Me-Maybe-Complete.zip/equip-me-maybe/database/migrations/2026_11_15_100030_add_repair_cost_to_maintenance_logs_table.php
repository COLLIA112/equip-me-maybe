<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('maintenance_logs', function (Blueprint $table) {
            $table->decimal('repair_cost', 12, 2)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('maintenance_logs', fn (Blueprint $table) => $table->dropColumn('repair_cost'));
    }
};
